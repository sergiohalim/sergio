const io = require("socket.io-client");
const readline = require("readline");

const socket = io("http://localhost:3000");

 const rl = readline.createInterface({
   input: process.stdin,
   output: process.stdout,
   prompt: "> ",
 });

 let registeredUsername = "";
 let username = "";
 const users = new Map();


socket.on("connect", () => {
    console.log("Connected to the server");

        rl.question("Enter your username: ", (input) => {
          registeredUsername = input;
          username = input;
        console.log(`Welcome, ${username} to the chat`);

        socket.emit("registerPublicKey", {
          username,
          publicKey: "public key",
        });
        rl.prompt();

        rl.on("line", (message) => {
          if (message.trim()) {
            if ((match = message.match(/^!impersonate (\w+)$/))) {
              username = match[1];
              console.log(`Now impersonating as ${username}`);
            } else if (message.match(/^!exit$/)) {
              username = registeredUsername;
              console.log(`Now you are ${username}`);
            } else {
              socket.emit("message", { username, message });
            }
          }
          rl.prompt();
        });
    });
});

socket.on("init", (keys) => {
  keys.forEach(([user, key]) => users.set(user, key));
  console.log(`\nThere are currently ${users.size} users in the chat`);
  rl.prompt();
});


socket.on("newUser", (data) => {
  const { username, publicKey } = data;
  users.set(username, publicKey);
  console.log(`${username} join the chat`);
  rl.prompt();
});

socket.on("message", (data) => {
    const { username: senderUsername, message: senderMessage } = data;
    if (senderUsername !== username) {
      console.log(`${senderUsername}: ${senderMessage}`);
    }
  });

    socket.on("disconnect", () => {
        console.log("Disconnected to the server"); 
        rl.close();
        process.exit(0);  

});

rl.on("SIGINT", () => {
    console.log("\nExiting...");
    socket.disconnect();
    rl.close();
    process.exit(0);
  });


// 
// const crypto = require("crypto");



// let targetUsername = "";
// 
// const users = new Map();

// const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
//   modulusLength: 2048,
//   publicKeyEncoding: { type: "spki", format: "pem" },
//   privateKeyEncoding: { type: "pkcs8", format: "pem" },
// });




//     socket.emit("registeredPublicKey", { username, publicKey });
//     rl.prompt();
//   });
// });

// rl.on("line", (message) => {
//   if (message.trim()) {
//     if (message.startsWith("!secret ")) {
//       const [_, target] = message.split(" ");
//       targetUsername = target;
//       console.log(`Now secretly chatting with ${targetUsername}`);
//     } else if (message === "!exit") {
//       console.log("Exiting secret chat");
//       targetUsername = "";
//     } else {
//       let encryptedMessage = message;
//       let isSecret = false;

//       if (targetUsername) {
//         const targetPublicKey = users.get(targetUsername);
//         if (targetPublicKey) {
//           encryptedMessage = crypto
//             .publicEncrypt(targetPublicKey, Buffer.from(message))
//             .toString("base64");
//           isSecret = true;
//           // console.log(`Encrypted message for ${targetUsername}: ${encryptedMessage}`);
//         } else {
//           console.log(`User ${targetUsername} not found`);
//         }
//       }

//       socket.emit("message", {
//         username,
//         message: encryptedMessage,
//         isSecret,
//         target: targetUsername,
//       });
//     }
//   }
//   rl.prompt();
// });


// socket.on("init", (keys) => {
//   keys.forEach(([user, key]) => users.set(user, key));
//   console.log(`\nThere are currently ${users.size} users in the chat`);
//   rl.prompt();
// });

// socket.on("newUser", (data) => {
//   const { username, publicKey } = data;
//   users.set(username, publicKey);
//   console.log(`${username} joined the chat`);
//   rl.prompt();
// });

// socket.on("secretChatStarted", ({ initiator }) => {
//   targetUsername = initiator;
//   rl.prompt();
// });

// socket.on("message", (data) => {
//   const { username: sender, message, isSecret, target } = data;

//   if (isSecret && target === username) {
//     try {
//       const decryptedMessage = crypto
//         .privateDecrypt(privateKey, Buffer.from(message, "base64"))
//         .toString();
//       console.log(` ${sender} (secret): ${decryptedMessage}`);
//     } catch (err) {
//       console.log(` Could not decrypt message from ${sender}`);
//     }
//   } else if (isSecret && target !== username) {
//     console.log(` ${sender} : ${message}`);  
//   } else {
//     console.log(`${sender}: ${message}`);
//   }
//   rl.prompt();
// });



//   rl.close();
//   process.exit(0);
// });

// rl.on("SIGINT", () => {
//   console.log("\nExiting...");
//   socket.disconnect();
//   rl.close();
//   process.exit(0);
// });
