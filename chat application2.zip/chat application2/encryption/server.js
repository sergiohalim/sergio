const http = require("http");
const socketIo = require("socket.io");

const server = http.createServer();
const io = socketIo(server);

const users = new Map(); 

io.on("connection", (socket) => {
  console.log(`Client ${socket.id} connected`);

  socket.emit("init", Array.from(users.entries()));


  socket.on("registerPublicKey", (data) => {
    const { username, publicKey } = data;
    users.set(username, publicKey);
    console.log(`${username} registered with public key.`);
    io.emit("newUser", {username, publicKey});
  });

  socket.on("message", (data) => {
    const { username, message } = data;
    io.emit("message", { username, message });
  });
    socket.on("disconnect", () => {
    console.log(`Client ${socket.id} disconnected`);
  });
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server running on port ${port}`);

});
//   socket.emit("init", Array.from(users.entries()));

//   socket.on("registeredPublicKey", (data) => {
//     const { username, publicKey } = data;
//     users.set(username, { socket, publicKey });
//     console.log(`${username} registered with public key`);
//     io.emit("newUser", { username, publicKey });
//   });

//   socket.on("message", (data) => {
//     const { username, message, isSecret, target } = data;

//     if (isSecret && target) {
//       const targetUser = users.get(target);
//       if (targetUser) {
//         console.log(`Sending secret message from ${username} to ${target}`);
//         // Send message to target user only
//         targetUser.socket.emit("message", { username, message, isSecret, target });
        
//         // Automatically notify target user that a secret chat has started
//         targetUser.socket.emit("secretChatStarted", { initiator: username });

//         // Send cipher text to everyone else (except the sender and target)
//         users.forEach((user, userKey) => {
//           if (userKey !== username && userKey !== target) {
//             user.socket.emit("message", { username, message, isSecret, target });
//           }
//         });
//       }
//     } else {
//       io.emit("message", { username, message, isSecret: false });
//     }
//   });

//   socket.on("disconnect", () => {
//     console.log(`Client ${socket.id} disconnected`);
//   });
// });

